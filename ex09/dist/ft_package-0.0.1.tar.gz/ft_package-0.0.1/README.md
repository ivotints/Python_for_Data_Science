# ft_package

A simple Python package created for educational purposes.

## Usage

```python
from ft_package import count_in_list
```

# Count occurrences of an item in a list
```
result = count_in_list(["toto", "tata", "toto"], "toto")  # Returns: 2
```
